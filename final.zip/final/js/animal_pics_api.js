fetch('https://some-random-api.ml/animal/dog')
    .then((response) => response.json())
    .then((jsObject) => {

        const imagesrc = jsObject.image;
        document.getElementById('pandaPhoto').setAttribute('src', imagesrc);
        document.getElementById('pandaPhoto').setAttribute('alt', "Panda Photo");
        document.getElementById('pandaPhoto').setAttribute('loading', 'lazy');


    });

fetch('https://some-random-api.ml/animal/cat')
    .then((response) => response.json())
    .then((jsObject) => {

        const imagesrc = jsObject.image;
        document.getElementById('pandaPhoto').setAttribute('src', imagesrc);
        document.getElementById('pandaPhoto').setAttribute('alt', "Panda Photo");
        document.getElementById('pandaPhoto').setAttribute('loading', 'lazy');


    });

fetch('https://some-random-api.ml/animal/panda')
    .then((response) => response.json())
    .then((jsObject) => {

        const imagesrc = jsObject.image;
        document.getElementById('pandaPhoto').setAttribute('src', imagesrc);
        document.getElementById('pandaPhoto').setAttribute('alt', "Panda Photo");
        document.getElementById('pandaPhoto').setAttribute('loading', 'lazy');


    });

fetch('https://some-random-api.ml/animal/fox')
    .then((response) => response.json())
    .then((jsObject) => {

        const imagesrc = jsObject.image;
        document.getElementById('pandaPhoto').setAttribute('src', imagesrc);
        document.getElementById('pandaPhoto').setAttribute('alt', "Panda Photo");
        document.getElementById('pandaPhoto').setAttribute('loading', 'lazy');


    });

fetch('https://some-random-api.ml/animal/red_panda')
    .then((response) => response.json())
    .then((jsObject) => {

        const imagesrc = jsObject.image;
        document.getElementById('pandaPhoto').setAttribute('src', imagesrc);
        document.getElementById('pandaPhoto').setAttribute('alt', "Panda Photo");
        document.getElementById('pandaPhoto').setAttribute('loading', 'lazy');


    });

fetch('https://some-random-api.ml/animal/koala')
    .then((response) => response.json())
    .then((jsObject) => {

        const src = jsObject.image;
        document.getElementById('koalaPhoto').setAttribute('src', src);
        document.getElementById('koalaPhoto').setAttribute('alt', "Koala Photo");
        document.getElementById('koalaPhoto').setAttribute('loading', 'lazy');


    });

fetch('https://some-random-api.ml/animal/birb')
    .then((response) => response.json())
    .then((jsObject) => {

        const src = jsObject.image;
        document.getElementById('koalaPhoto').setAttribute('src', src);
        document.getElementById('koalaPhoto').setAttribute('alt', "Koala Photo");
        document.getElementById('koalaPhoto').setAttribute('loading', 'lazy');


    });

fetch('https://some-random-api.ml/animal/racoon')
    .then((response) => response.json())
    .then((jsObject) => {

        const src = jsObject.image;
        document.getElementById('racoonPhoto').setAttribute('src', src);
        document.getElementById('racoonPhoto').setAttribute('alt', "Racoon Photo");
        document.getElementById('racoonPhoto').setAttribute('loading', 'lazy');


    });

fetch('https://some-random-api.ml/animal/kangaroo')
    .then((response) => response.json())
    .then((jsObject) => {

        const src = jsObject.image;
        document.getElementById('kangarooPhoto').setAttribute('src', src);
        document.getElementById('kangarooPhoto').setAttribute('alt', "Kangaroo Photo");
        document.getElementById('kangarooPhoto').setAttribute('loading', 'lazy');


    });

fetch('https://some-random-api.ml/animal/whale')
    .then((response) => response.json())
    .then((jsObject) => {

        const imagesrc = jsObject.image;
        document.getElementById('pandaPhoto').setAttribute('src', imagesrc);
        document.getElementById('pandaPhoto').setAttribute('alt', "Panda Photo");
        document.getElementById('pandaPhoto').setAttribute('loading', 'lazy');


    });